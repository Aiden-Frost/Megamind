from megamind.megamind_rdv  import Activation_Functions, Weight_Initialization,
Regularization_Functions, Drop_Out, Optimizers, Cost_Functions, Architecture,
generate_mini_batches